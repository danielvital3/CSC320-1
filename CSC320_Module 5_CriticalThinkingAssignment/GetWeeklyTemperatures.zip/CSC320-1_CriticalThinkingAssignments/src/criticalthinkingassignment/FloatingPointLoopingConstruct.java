package criticalthinkingassignment;

import java.util.Scanner;

public class FloatingPointLoopingConstruct {
	   public static void main(String[] args) {
		    int i = 0;
    	    float total = 0;
    	    float average = 0;
    	    float max = Float.NEGATIVE_INFINITY;  
    	    float min = Float.POSITIVE_INFINITY;   
    	    float interest = 0;
    	    float[] userValues = new float[5];
    	    
		    Scanner scnr = new Scanner(System.in);
    	    
    	    //loop construct to get values and find total, max, and mix values
    	    while (i < 5) {
    		      System.out.print("Please enter a number: ");
    		      userValues[i] = scnr.nextFloat();
    		      total = total + userValues[i];
    		      
    		      if (userValues[i] > max) {
    		    	  max = userValues[i];
    		      }
    		      
    		      if (userValues[i] < min) {
    		    	  min = userValues[i];
    		      }
    		      
    		      i++;

    	    }
    	    
    	    scnr.close();

    	    average = total / userValues.length;
    	    interest = total * 0.20f;
    	    
    	    System.out.print("Input values: ");
    	    System.out.println("Total: " + total);
    	    System.out.println("Average: " + average);
    	    System.out.println("Maximum: " + max);
    	    System.out.println("Minimum: " + min);
    	    System.out.println("Interest on total at 20%: " + interest);

    	    
      }
}