package criticalthinkingassignment;

import java.util.Scanner;

public class GetWeeklyTemperatures {
	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);

		// Define arrays and variable
		String[] daysOfWeek = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
		double[] dayAverageTemperature = { 35, 55, 33, 28, 31, 29, 34 };

		double weekAverageTemperature;
		double tempSumVal;
		String userInput;

		boolean foundDay = false;
		int i;
		
		System.out.print("Please enter a day of the week or the word 'week': ");
		userInput = scnr.nextLine().trim();

		while (true) {
			// Check if the user wants the weekly average temperature
			if (userInput.equalsIgnoreCase("week")) {
				tempSumVal = 0;
				for (i = 0; i < daysOfWeek.length; ++i) {
					tempSumVal += dayAverageTemperature[i];
				}
				weekAverageTemperature = tempSumVal / daysOfWeek.length;
				System.out.println("Average temperature for the week: " + weekAverageTemperature + "\u00B0F");
				break;
			}

			// Check if the input matches one of the days
			for (i = 0; i < daysOfWeek.length; ++i) {
				if (userInput.equalsIgnoreCase(daysOfWeek[i])) {
					System.out.println(
							"Average temperature on " + daysOfWeek[i] + ": " + dayAverageTemperature[i] + "\u00B0F");
					foundDay = true;
					break;
				}
			}

			// If a valid day was found, exit the while loop
			if (foundDay) {
				break;
			}

			// Otherwise, prompt for input again if neither "week" nor a valid day was
			System.out.print("Invalid input. Please enter a valid day (Monday through Sunday) or 'week': ");
			userInput = scnr.nextLine().trim();
		}

	}
}


