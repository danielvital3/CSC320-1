package criticalthinkingassignment;

public class RestaurantInfo {
	public static void main (String[] args) {
		//Declare and initialized variables
		String restaurantName = "Katz's Delicatessen"; 
		String businessAddress = "205 E Houston St";
		String city = "New York City"; 
		String state = "New York"; 
		String zipCode = "10002";
		
		//Output restaurant information
		System.out.println("Restaurant: " + restaurantName);
		System.out.println("Address: " + businessAddress);
		System.out.println("City: " + city);
		System.out.println("State: " + state);
		System.out.println("Zip code: " + zipCode);
	
	}
}